<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<x-head></x-head>

<body class="">
  <header>
    <x-menu></x-menu>
  </header>
  <main class="h-screen flex flex-col justify-center items-center">
    @if (session('success'))
      <div id="success-alert" class="alert alert-success cursor-pointer" onclick="this.style.display='none'">
        <ul class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
          <li>{{ session('success') }}</li>
        </ul>
      </div>
    @endif
    <div class="container mx-auto my-4">
      <ul class="flex flex-col gap-4 mt-4 justify-center items-center">
        
        @if (is_null($tienda))
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/vendedor/crear_tienda" class="">Crear Tienda</a>
          </li>
        @else
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
              <a href="/vendedor/editar_tienda">Editar Tienda</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/vendedor/editar_elemento">Editar Elemento</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
          <a href="/vendedor/hacer_post">Hacer un Post</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
              <a href="/vendedor/nuevo_servicio">Añadir un Servicio</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/vendedor/nuevo_producto">Añadir un Producto Físico</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/vendedor/eliminar_elemento">Eliminar Elemento (Servicio o Producto)</a>
          </li>
          <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/vendedor/pedidos_pendientes">Pedidos Pendientes</a>
          </li>
        @endif
  
        
        <li class="text-2xl font-bold border-b-2 border-red-300 hover:bg-red-200">
          <a href="/cerrar_sesion">Salir</a>
        </li>
      </ul>
     
  </main>

  <footer>
    <x-footer></x-footer>
  </footer>
</body>

</html>