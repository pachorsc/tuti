<li class="max-w-4xl mx-auto bg-gray-100 p-4 rounded-md shadow-md flex gap-4">
  <!-- Imagen -->
  <div class="w-1/3">
    <div class="aspect-video rounded-md">
      <img src="<?php echo e(explode('***', $imagen)[0]); ?>" alt="<?php echo e($titulo); ?>" class="w-full h-full object-cover rounded-md">
    </div>
  </div>

  <!-- Contenido -->
  <div class="w-2/3 flex flex-col justify-between">
    <div>
      <p class="text-sm text-gray-600 mb-1"><?php echo e($categoria); ?></p>
      <h2 class="text-lg font-semibold text-gray-800 leading-tight">
        <?php echo e($titulo); ?>

      </h2>
      <p class="text-sm text-gray-700 mt-2">
        <?php echo e($contenido); ?>...
      </p>
    </div>
    <a href="/blog/<?php echo e($codigo); ?>" class="mt-4 text-sm text-blue-600 hover:underline">Leer Artículo</a>
  </div>
</li><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/components/articulo_lista.blade.php ENDPATH**/ ?>