<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tuti</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <script src="http://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
</head>

<body class="overflow-x-hidden h-screen bg-gray-50 text-gray-900 font-sans antialiased">
    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>
    <main class="max-w-5xl mx-auto p-6 h-screen">

        <h1 class="text-2xl font-bold mb-6">Mis pedidos</h1>

        <?php if(session('mensaje')): ?>
            <div x-data="{ show: true }" x-show="show" @click="show = false"
                class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded cursor-pointer max-w-xl mx-auto my-4 shadow transition-opacity duration-300"
                title="Haz clic para cerrar">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(count($pedidos) == 0): ?>
            <div class="bg-white p-6 rounded shadow text-center text-gray-500">
                No tienes pedidos realizados.
            </div>
        <?php else: ?>
            <div class="space-y-6">
                <?php for($i = 0; $i < count($pedidos); $i++): ?>
                    <div class="bg-white rounded shadow p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                        <div>
                            <p class="font-semibold text-lg mb-1">Pedido #<?php echo e($pedidos[$i]->id); ?></p>
                            <p class="text-gray-600 text-sm mb-1">Fecha:
                                <?php echo e(\Carbon\Carbon::parse($pedidos[$i]->fecha_pedido)->format('d/m/Y H:i')); ?>

                            </p>
                            <p class="text-gray-600 text-sm mb-1">Tienda: <?php echo e($tiendas[$i]->nombre ?? 'N/A'); ?></p>
                            <p class="text-gray-600 text-sm mb-1">Dirección: <?php echo e($tiendas[$i]->direccion); ?></p>
                            <p class="text-gray-600 text-sm mb-1">Productos:

                                <?php $__currentLoopData = explode(';', $pedidos[$i]->elementos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        if (empty($prod))
                                            continue;
                                        $partes = explode(':', $prod);
                                        if (count($partes) < 2)
                                            continue;
                                        list($producto_id, $cantidad) = $partes;
                                    ?>
                                    <span class="inline-block bg-gray-100 rounded px-2 py-1 text-xs mr-1 mb-1">
                                        x<?php echo e($cantidad); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </div>
                        <div class="flex flex-col items-end gap-2">
                            <span class="text-lg font-bold text-gray-800">Total:
                                <?php echo e(number_format($pedidos[$i]->precio_total, 2)); ?>

                                €</span>
                            <span class="px-3 py-1 rounded-full text-xs font-semibold
                                                            <?php if($pedidos[$i]->estado == false): ?> bg-yellow-100 text-yellow-700
                                                                <?php else: ?> bg-green-100 text-green-700
                                                            <?php endif; ?>">
                                <?php if($pedidos[$i]->estado == false): ?>
                                    En preparación
                                <?php else: ?>
                                    Listo
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/ver_pedidos.blade.php ENDPATH**/ ?>