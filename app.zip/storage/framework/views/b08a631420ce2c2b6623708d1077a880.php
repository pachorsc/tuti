<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Tuti</title>

  <!-- Fonts -->
  <link rel="preconnect" href="https://fonts.bunny.net">
  <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

  <!-- Styles / Scripts -->
  <script src="http://cdn.tailwindcss.com"></script>

</head>

<body class="">
  <header>
    <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
  </header>
  <main class="h-screen flex flex-col justify-center items-center">
    <?php if(session('success')): ?>
      <div class="alert alert-success">
        <ul class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
          <li><?php echo e(session('success')); ?></li>
        </ul>
      </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
      <div class="alert alert-success">
        <ul class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <li><?php echo e(session('error')); ?></li>
        </ul>
      </div>
    <?php endif; ?>
    <div class="container mx-auto my-4">
      <ul class="flex flex-col gap-4 mt-4 justify-center items-center">
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/admin/Anadir_usuario" class="">Añadir Usuario Vendedor</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/admin/anadir_categoria">Añadir Categoría</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
          <a href="/admin/Eliminar_Usuarios">Eliminar Usuarios</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
            <a href="/admin/tienda_eliminar_post">Eliminar Posts</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
          <a href="/admin/eliminar_categoria">Eliminar Categoría</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-gray-300 hover:bg-gray-200">
          <a href="/admin/eliminar_producto">Eliminar Productos de la Tienda</a>
        </li>
        <li class="text-2xl font-bold border-b-2 border-red-300 hover:bg-red-200">
          <a href="/cerrar_sesion">Salir</a>
        </li>
      </ul>
     
  </main>

  <footer>
    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
  </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/admin/admin.blade.php ENDPATH**/ ?>