<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tuti</title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <script src="http://cdn.tailwindcss.com"></script>
    <script src="//unpkg.com/alpinejs" defer></script>
</head>

<body class="overflow-x-hidden">
    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>
    <main>
        <div class="max-w-md mx-auto p-4 space-y-6">
            <div
                class="bg-gray-400 p-4 rounded-md flex flex-col sm:flex-row items-center sm:items-start justify-between space-y-4 sm:space-y-0 sm:space-x-4">

                <div class="w-24 h-24 bg-gray-300 flex items-center justify-center text-gray-600 text-xs">
                    <img class="w-full" src="<?php echo e(asset($producto[0]->imagen)); ?>" alt="">
                </div>

                <div class="flex-1 text-center sm:text-left">
                    <p class="font-bold text-black"><?php echo e($nombre); ?></p>
                    <p class="text-sm text-gray-800 font-medium">
                        <strong>Precio: </strong>
                        <?php if($producto[0]->precio_descuento): ?>
                            <span class="line-through font-light text-red-400 mr-2"><?php echo e($producto[0]->precio); ?>€</span>
                            <span class="text-black font-bold"><?php echo e($producto[0]->precio_descuento); ?>€</span>
                        <?php else: ?>
                            <?php echo e($producto[0]->precio); ?>€
                        <?php endif; ?>
                    </p>
                </div>

                <?php if($producto[1]): ?>
                        <form action="/reservar_producto" method="post">
                            <?php echo csrf_field(); ?>
                            <div x-data="{ cantidad: 1 }" class="flex items-center space-x-2">
                                <button class="px-2 py-1 bg-gray-200 rounded" @click="if(cantidad > 1)cantidad--"
                                    type="button">-</button>

                                <input type="number" name="cantidad" :value="cantidad" readonly
                                    class="w-10 text-center border rounded bg-white" />

                                <button class="px-2 py-1 bg-gray-200 rounded"
                                    @click="if(cantidad < <?php echo e($producto[0]->cantidad); ?>) cantidad++" type="button">+</button>
                            </div>


                    </div>
                    <div class="text-center sm:text-left">
                        <p class="font-semibold">Método de pago</p>
                        <div class="inline-block relative">
                            <select class="appearance-none px-4 py-2 pr-8 rounded bg-gray-200">
                                <option>En tienda</option>
                            </select>
                            <div class="absolute right-2 top-2 pointer-events-none">
                                <span class="text-sm">⬇</span>
                            </div>
                        </div>
                    </div>
                    <input type="number" hidden name="producto" value="<?php echo e($producto[0]->id); ?>">
                    <div class="text-center">
                        <button type="submit" class="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">
                            Añadir al carrito
                        </button>
                    </div>
                    </form>
                <?php else: ?>
                </div>
                <h3>Debido a que este servicio depende de la disponibilidad de la tienda este tipo de servicios se reservan
                    directamente con la tienda</h3>

                <ul>
                    <li><strong>Telefono: </strong><?php echo e($tienda->telefono); ?></li>
                    <li><strong>Direccion: </strong><?php echo e($tienda->direccion); ?></li>
                    <li><strong>Horario: </strong><?php echo e($tienda->horario); ?></li>
                </ul>
                <div>
                    <img class="w-100" src="<?php echo e(asset($tienda->imagen)); ?>" alt="">
                </div>


            <?php endif; ?>
        </div>

    </main>

    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/reserva.blade.php ENDPATH**/ ?>