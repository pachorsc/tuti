<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>

<body class="">

    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>

    <main class="flex-1 max-w-5xl mx-auto w-full px-4 py-8">

        <h1 class="text-2xl md:text-3xl font-bold text-center mb-6"><?php echo e($tienda->nombre); ?></h1>

        <div class="w-full aspect-video bg-gray-300 rounded-lg mb-8 flex items-center justify-center overflow-hidden">
            <img src="<?php echo e(asset($tienda->imagen)); ?>" alt="Imagen de la tienda" class="object-cover w-full h-full">
        </div>

        <div class="mb-10">
            <h2 class="text-lg font-semibold mb-2">Ubicación</h2>
            <div
                class="w-full h-56 md:h-64 bg-gray-200 border-2 border-blue-400 rounded-lg flex items-center justify-center overflow-hidden">
                <?php if(isset($tienda->direccion) && $tienda->direccion): ?>
                    <iframe width="100%" height="100%" frameborder="0" style="border:0; min-height: 100%; min-width: 100%;"
                        src="https://www.google.com/maps?q=<?php echo e(urlencode($tienda->direccion)); ?>&hl=es&z=16&output=embed"
                        allowfullscreen>
                    </iframe>
                <?php else: ?>
                    <span class="text-gray-500">Mapa no disponible</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="mb-10">
            <h2 class="text-lg font-semibold mb-2">Mejores productos / Servicios</h2>
            <div class="flex space-x-4 overflow-x-auto bg-gray-200 rounded-lg p-4">
                <?php for($i = 0; $i < count($productos); $i++): ?>
                    <a href="<?php echo e('/producto/' . $tienda->nombre . '/' . $productos[$i]->id); ?>"
                        class="min-w-[120px] shadow h-32 bg-[url('<?php echo e(asset($productos[$i]->imagen)); ?>')] bg-cover bg-center rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        <span class="text-black bg-amber-100"><?php echo e(str_replace('_', ' ', $productos[$i]->nombre)); ?></span>
                    </a>
                <?php endfor; ?>
            </div>
        </div>

        <?php if(count($posts) > 0): ?>
            <div class="mb-10">
                <h2 class="text-lg font-semibold mb-4">Blog</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 bg-gray-200 rounded-lg p-4">
                    <?php for($i = 0; $i < count($posts); $i++): ?>
                        <a href="<?php echo e('/blog/' . $posts[$i]->id); ?>" class="bg-gray-500 rounded-lg p-3 flex flex-col">
                            <div class="w-full h-24 bg-gray-400 rounded mb-2">
                                <img src="<?php echo e(asset($posts[$i]->imagen)); ?>" alt="<?php echo e($posts[$i]->titulo); ?>"
                                    class="w-full h-full object-cover rounded">
                            </div>
                            <div class="font-semibold text-white mb-1"><?php echo e(explode(';;;',$posts[$i]->titulo)[0]); ?></div>
                            <div class="text-gray-300 text-sm mb-2"><?php echo e(Str::limit(explode(';;;',$posts[$i]->titulo)[1], 50)); ?></div>
                        </a>
                    <?php endfor; ?>
                </div>
            </div>

        <?php endif; ?>
    </main>


    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>

</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/ver_tienda.blade.php ENDPATH**/ ?>