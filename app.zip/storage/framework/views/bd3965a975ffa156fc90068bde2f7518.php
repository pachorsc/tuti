<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>

<body class="overflow-x-hidden">
    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <main>

        <div class="p-4 max-w-7xl mx-auto mt-2">
            <!-- Sección Principal -->
            <div class="flex flex-col lg:flex-row gap-6">
                <!-- Imágenes laterales -->
                <div class="flex lg:flex-col gap-2 order-2 lg:order-1">

                    <div class="w-16 h-16 shadow">
                        <img class="w-full" src="<?php echo e(asset($datos_producto->imagen)); ?>"
                            alt="<?php echo e($datos_producto->nombre); ?>">
                    </div>

                </div>

                <!-- Imagen principal -->
                <div class="flex-1 order-1 lg:order-2 shadow">
                    <div class="aspect-square w-full">
                        <img src="<?php echo e(asset($datos_producto->imagen)); ?>" alt="Imagen del producto"
                            class="w-full h-full object-cover">
                    </div>
                </div>

                <!-- Descripción -->
                <div class="flex-1 order-3 space-y-4">
                    <h2 class="text-xl font-semibold"><?php echo e($datos_producto->nombre); ?></h2>
                    <p class="text-gray-600 text-sm">
                        <?php echo e($datos_producto->descripcion); ?>

                    </p>

                    <p class="text-sm text-gray-800 font-medium"><strong>Precio: </strong>
                        <?php if($datos_producto->precio_descuento): ?>
                            <span class="line-through text-red-400 mr-2"><?php echo e($datos_producto->precio); ?>€</span>
                            <span class="text-green-600 font-bold"><?php echo e($datos_producto->precio_descuento); ?></span>
                        <?php else: ?>
                            <?php echo e($datos_producto->precio); ?>

                        <?php endif; ?> €
                    </p>
                    <?php if($is_producto): ?>
                        <p class="text-sm text-gray-800 font-medium"><strong>Color: </strong><?php echo e($datos_producto->color); ?></p>
                        <p class="text-sm text-gray-800 font-medium"><strong>Stock: </strong> <?php echo e($datos_producto->cantidad); ?>

                        </p>
                    <?php else: ?>
                        <p><strong>Horario: </strong><?php echo e($datos_producto->horario_disp); ?></p>
                    <?php endif; ?>
                    <?php if(!$iniciado): ?>
                        <a href="/entrar" class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded inline-block">
                            Iniciar Sesión para Reservar
                        </a>
                    <?php elseif(Cookie::get('vendedor') != null): ?>
                        <a class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded inline-block">
                            Reservar
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(asset('/reserva/' . $datos_producto->nombre . '/' . $datos_producto->id)); ?>"
                            class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded inline-block">
                            Reservar
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sección Servicios Relacionados -->
            <div class="mt-10">
                <h3 class="text-lg font-semibold mb-4">Productos Relacionados</h3>
                <div class="bg-gray-200 p-4 ">
                    <div class="flex gap-4 min-w-max flex-col md:flex-row">
                        <?php $__currentLoopData = $otros_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset('/producto/' . $producto->nombre . '/' . $producto->id)); ?>"
                                class="flex justify-center items-center md:w-1/5 h-32 bg-cover bg-center bg-[url(<?php echo e(asset($producto->imagen)); ?>)]">
                                <span
                                    class="text-white font-bold transition-transform duration-300 hover:scale-105 bg-[#EEC643] p-2 rounded-3xl text-center"><?php echo e($producto->nombre); ?></span>
                            </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </main>

    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/producto.blade.php ENDPATH**/ ?>