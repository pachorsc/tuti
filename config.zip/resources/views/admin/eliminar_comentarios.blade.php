<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<x-head></x-head>

<body class="">
  <header>
    <x-menu></x-menu>
  </header>
  <main>
    <h1>aun nada wey</h1>
  </main>

  <footer>
    <x-footer></x-footer>
  </footer>
</body>

</html>