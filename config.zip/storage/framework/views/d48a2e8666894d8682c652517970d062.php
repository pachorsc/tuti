<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>

<body class="" x-data="{ cargando: true }" x-init="
    let timeout = setTimeout(() => { cargando = false }, 5000); // Oculta el loader tras 5 segundos
    navigator.geolocation.getCurrentPosition(
        function() { cargando = false; clearTimeout(timeout); },
        function() { cargando = false; clearTimeout(timeout); }
    );
">
    <div x-show="cargando"
        class="fixed inset-0 bg-white bg-opacity-80 flex items-center justify-center z-50 transition-opacity">
        <div class="flex flex-col items-center">
            <svg class="animate-spin h-12 w-12 text-yellow-400 mb-4" xmlns="http://www.w3.org/2000/svg" fill="none"
                viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"></path>
            </svg>
            <span class="text-lg font-semibold text-yellow-600">Cargando ubicación...</span>
        </div>
    </div>
    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <main>

        <body class="bg-gray-100 text-gray-800">


            <!-- Post Principal y Secundarios -->
            <section class="container h-[50vh] mx-auto p-4 grid grid-cols-1 lg:grid-cols-3 gap-4">
                <a href="<?php echo e('/blog/' . $datos['posts'][0]->id); ?>"
                    class="rounded transition-transform duration-300 hover:scale-105 lg:col-span-2 bg-cover bg-center h-full bg-[url('<?php echo e(explode('***', $datos['posts'][0]->imagen)[0]); ?>')] bg-gray-300 flex items-center justify-center">
                    <span
                        class="text-white font-bold text-xl bg-[#EEC643] w-full text-center"><?php echo e($datos['posts'][0]->titulo); ?></span>
                </a>
                <div class="flex flex-col gap-4">
                    <a href="<?php echo e('/blog/' . $datos['posts'][1]->id); ?>"
                        class="rounded transition-transform duration-300 hover:scale-105 h-full bg-cover bg-center bg-[url('<?php echo e(explode('***', $datos['posts'][1]->imagen)[0]); ?>')] flex items-center justify-center">
                        <span
                            class="text-white font-bold text-xl bg-[#EEC643] w-full text-center"><?php echo e($datos['posts'][1]->titulo); ?></span>
                    </a>
                    <a href="<?php echo e('/blog/' . $datos['posts'][2]->id); ?>"
                        class="rounded transition-transform duration-300 hover:scale-105 h-full bg-cover bg-center bg-[url('<?php echo e(explode('***', $datos['posts'][2]->imagen)[0]); ?>')] flex items-center justify-center">
                        <span
                            class="text-white font-bold text-xl bg-[#EEC643] w-full text-center"><?php echo e($datos['posts'][2]->titulo); ?></span>
                    </a>
                </div>
            </section>

            <!-- Suscripción -->
            <section class="container mx-auto p-4">
                <div class="bg-[#247BA0] p-4 flex flex-col sm:flex-row items-center justify-center space-x-5z gap-4">
                    <span class="text-lg font-semibold">Suscríbete y sabras todas las novedades de las tiendas cerca de
                        ti</span>
                    <div class="flex  w-full sm:w-auto">
                        <input type="email" placeholder="Tu correo"
                            class="p-2 border border-gray-400 rounded-l w-full sm:w-auto" />
                        <button class="bg-gray-500 text-white px-4 rounded-r">Entrar</button>
                    </div>
                </div>
            </section>

            <!-- Categorías -->
            <section class="container flex flex-col mx-auto p-4 gap-4">
                <h1 class="text-xl font-semibold">Categorías cercanas</h1>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <?php $__currentLoopData = $datos['categorias']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e('/blog/categoria/' . $categoria['nombre']); ?>"
                            class="bg-[url('<?php echo e($categoria['imagen']); ?>')] bg-cover bg-center h-24 flex items-center justify-center shadow rounded transition-transform duration-300 hover:scale-105"><span
                                class="text-white font-bold text-xl bg-[#EEC643] p-2 rounded-3xl text-center"><?php echo e($categoria['nombre']); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </section>

            <!-- Ofertas de la semana -->
            <section class="container mx-auto p-4">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Ofertas de la semana</h2>
                    <a href="#" class="text-blue-500 text-sm">Ver más →</a>
                </div>
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                    <?php $__currentLoopData = $datos['productos']->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e('/producto/' . $producto->nombre . '/' . $producto->id); ?>"
                            class="shadow transition-transform duration-300 hover:scale-105 bg-[url('<?php echo e($producto->imagen); ?>')] bg-cover bg-center h-32 flex items-center justify-center"><span
                                class="text-white font-bold sm:text-xl text-sm bg-[#EEC643] p-2 rounded-3xl text-center"><?php echo e($producto->nombre); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

            
            
            <section class="container mx-auto p-4 my-2">
                <h2 class="text-xl font-semibold my-2">Tiendas cercanas</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <?php $__currentLoopData = $datos['tiendas_cercanas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal3b10d2215022aebf1221ed9e97aa3fa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b10d2215022aebf1221ed9e97aa3fa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tienda','data' => ['nombre' => $tienda['nombre'],'imagen' => $tienda['imagen'],'id' => $tienda['id']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tienda'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['nombre' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tienda['nombre']),'imagen' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tienda['imagen']),'id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tienda['id'])]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b10d2215022aebf1221ed9e97aa3fa0)): ?>
<?php $attributes = $__attributesOriginal3b10d2215022aebf1221ed9e97aa3fa0; ?>
<?php unset($__attributesOriginal3b10d2215022aebf1221ed9e97aa3fa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b10d2215022aebf1221ed9e97aa3fa0)): ?>
<?php $component = $__componentOriginal3b10d2215022aebf1221ed9e97aa3fa0; ?>
<?php unset($__componentOriginal3b10d2215022aebf1221ed9e97aa3fa0); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

        </body>
    </main>

    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>
   
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/welcome.blade.php ENDPATH**/ ?>