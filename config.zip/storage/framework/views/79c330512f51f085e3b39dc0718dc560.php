<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Tuti</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <!-- Styles / Scripts -->
    <script src="http://cdn.tailwindcss.com"></script>

</head>

<body class="">
    <header>
        <?php if (isset($component)) { $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.menu','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $attributes = $__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__attributesOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0)): ?>
<?php $component = $__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0; ?>
<?php unset($__componentOriginal5893a4ae82cbde8a6e1ba16203c33ac0); ?>
<?php endif; ?>
    </header>

    <main class="bg-gray-100 flex items-center justify-center min-h-screen">
        <div class="flex flex-col md:flex-row items-center justify-center gap-8 w-full max-w-5xl p-4">
            <!-- Formulario -->
            <div class="w-full md:w-1/2 bg-gray-300 p-6 rounded-md shadow-md">
                <h2 class="text-2xl font-bold text-center mb-4">Crear Post</h2>
                <form method="POST" action="/vendedor/insert_post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="block font-semibold mb-1">Titulo</label>
                        <input name="titulo[]" type="text"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">

                    </div>
                    <div>
                        <label class="block font-semibold mb-1">Subtitulo</label>
                        <input name="titulo[]" type="text"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">

                    </div>
                    <div>
                        <label class="block font-semibold mb-1">Imagen</label>
                        <input name="imagen[]" type="file" accept="image/*"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">

                    </div>
                    <div id="add-image2-btn"
                        class="flex items-center justify-center bg-amber-200 rounded-md p-2 my-4 w-20 mx-auto cursor-pointer hover:bg-amber-300">
                        <span>+</span>
                    </div>
                    <div id="imagen2-div" style="display:none">
                        <label class="block font-semibold mb-1">Imagen</label>
                        <input name="imagen2" type="file" accept="image/*"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block font-semibold mb-1">Parrafo</label>
                        <textarea name="parrafo[]" rows="4"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>

                    </div>

                    <div id="partes-container"></div>

                    <div id="add-parte-btn"
                        class="flex items-center justify-center bg-amber-200 rounded-md p-2 my-4 w-20 mx-auto cursor-pointer hover:bg-amber-300">
                        <span>+</span>
                    </div>



                    <div class="text-center">
                        <button type="submit"
                            class="bg-white px-6 py-2 my-2 rounded shadow hover:bg-gray-200 font-semibold">
                            Crear Post
                        </button>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            <ul class="list-disc pl-5">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </main>

    <footer>
        <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
    </footer>
    <script>
        let parte = `
                    <div>
                        <label class="block font-semibold mb-1">Titulo</label>
                        <input name="titulo[]" type="text"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <?php $__errorArgs = ['Titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 font-semibold text-sm mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label class="block font-semibold mb-1">Imagen</label>
                        <input name="imagen[]" type="file" accept="image/*"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block font-semibold mb-1">Parrafo</label>
                        <textarea name="parrafo[]" rows="4"
                            class="w-full p-2 rounded bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                    </div>`;
        document.getElementById('add-image2-btn').addEventListener('click', function () {
            document.getElementById('imagen2-div').style.display = 'block';
            this.style.display = 'none';
        });

        document.getElementById('add-parte-btn').addEventListener('click', function () {
            document.getElementById('partes-container').insertAdjacentHTML('beforeend', parte);
        });

    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\tuti3\resources\views/dueno/hacer_post.blade.php ENDPATH**/ ?>